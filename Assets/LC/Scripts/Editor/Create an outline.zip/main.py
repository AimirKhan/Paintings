import cv2
import numpy as np


def viewImage(image, name_of_window):
    cv2.namedWindow(name_of_window, cv2.WINDOW_NORMAL)
    cv2.imshow(name_of_window, image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


def get_area_of_each_gray_level(im):
    image = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)

    high = 90
    low = 60

    to_be_black_again_low = np.array([high])
    to_be_black_again_high = np.array([255])
    curr_mask = cv2.inRange(image, to_be_black_again_low, to_be_black_again_high)
    image[curr_mask > 0] = (0)
    ret, threshold = cv2.threshold(image, low, 255, 0)
    contours, hirerchy = cv2.findContours(threshold, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)

    cv2.drawContours(im, contours[len(contours) - 1], -1, (29, 230, 181), 3)

    for i in range(len(contours) - 1):
        cv2.drawContours(im, contours[i], -1, (0, 0, 255), 3)
    high -= 15
    return contours


def create_json_by_image(folder_in, folder_out, file_name, file_format):
    path = folder_in + '\\' + file_name + '.' + file_format
    step = 1
    img = cv2.imread(path)
    array = get_area_of_each_gray_level(img)

    f = open(folder_out + '\\' + file_name + '.json', 'w')

    height = np.size(img, 0)
    width = np.size(img, 1)

    f.write('{"Height":')
    f.write(str(height))
    f.write(',"Width":')
    f.write(str(width))
    f.write(',"dots":[')

    if len(array) > 1:
        print("Error: '" + folder_in + '\\' + file_name + '.' + file_format + "' find parts: " + str(len(array)))

    for i in range(len(array)):
        for j in range(len(array[i])):
            f.write('{')
            f.write('"x":')
            f.write(str(float(array[i][j][0][0])))
            f.write(',')
            f.write('"y":')
            f.write(str(float(array[i][j][0][1])))
            f.write('}')
            if j != len(array[i]) - 1:
                f.write(',')

    f.write(']')
    f.write('}')
    f.close()

    viewImage(img, file_name + '.' + file_format)


#for i in range(25, 26):
#    create_json_by_image('H:\\data\\22', 'H:\\data\\json2', str(i), 'png')
    
create_json_by_image('H:\\data\\22', 'H:\\data\\json2', "temp", 'png')

